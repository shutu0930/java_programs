package myPackage;
import java.util.HashMap;

public class Subs extends HashMap<String, Integer>{

}
